<?php

echo 'God Try but maybe you need read me to get the flag!!';

//$flag = 'bitup19{s1mb0l1c_l1nkS_RuL3sS}';

?>
