<?php

echo 'Jajaja no more stupid bugs! Sorry read me if you can :)';

//$flag = 'bitup19{3p1c_P4tH_Tr4nSvers4l_&_LF1}';

?>
